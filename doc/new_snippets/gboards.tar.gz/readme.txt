Originally written by Erwin Andreasen(www.andreasen.org)
Ported by Kratas (moon@deathmoon.com)

Make a backup of your current code, then do:

patch < global_boards.patch

Ok, next, do the following, then make clean and compile!


Open mud.h, search for CON_PLAYING, after the last con state, put:
, CON_NOTE_TO, CON_NOTE_SUBJECT, CON_NOTE_EXPIRE, CON_NOTE_TEXT,
CON_NOTE_FINISH.

next, search for PC_DATA, at the end of it, put:

GLOBAL_BOARD_DATA *board;
time_t last_note[MAX_BOARD];
NOTE_DATA *in_progress;
