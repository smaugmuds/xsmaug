/****************************************************************************
 *                   ^     +----- |  / ^     ^ |     | +-\                  *
 *                  / \    |      | /  |\   /| |     | |  \                 *
 *                 /   \   +---   |<   | \ / | |     | |  |                 *
 *                /-----\  |      | \  |  v  | |     | |  /                 *
 *               /       \ |      |  \ |     | +-----+ +-/                  *
 ****************************************************************************
 * AFKMud Copyright 1997-2007 by Roger Libiez (Samson),                     *
 * Levi Beckerson (Whir), Michael Ward (Tarl), Erik Wolfe (Dwip),           *
 * Cameron Carroll (Cam), Cyberfox, Karangi, Rathian, Raine, and Adjani.    *
 * All Rights Reserved.                                                     *
 * Registered with the United States Copyright Office. TX 5-877-286         *
 *                                                                          *
 * External contributions from Xorith, Quixadhal, Zarius, and many others.  *
 *                                                                          *
 * Original SMAUG 1.4a written by Thoric (Derek Snider) with Altrag,        *
 * Blodkai, Haus, Narn, Scryn, Swordbearer, Tricops, Gorog, Rennard,        *
 * Grishnakh, Fireblade, and Nivek.                                         *
 *                                                                          *
 * Original MERC 2.1 code by Hatchet, Furey, and Kahn.                      *
 *                                                                          *
 * Original DikuMUD code by: Hans Staerfeldt, Katja Nyboe, Tom Madsen,      *
 * Michael Seifert, and Sebastian Hammer.                                   *
 ****************************************************************************
 * Comments: 'notes' attached to players to keep track of outstanding       * 
 *           and problem players.  -haus 6/25/1995                          * 
 ****************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include "mud.h"
#include "boards.h"

void note_attach( CHAR_DATA * ch );
void free_note( NOTE_DATA * pnote );
void fwrite_note( NOTE_DATA * pnote, FILE * fp );
NOTE_DATA *read_note( FILE * fp );
void note_to_char( CHAR_DATA * ch, NOTE_DATA * pnote, BOARD_DATA * board, short id );

void free_comments( CHAR_DATA * ch )
{
   NOTE_DATA *comment, *comment_next;

   for( comment = ch->pcdata->first_comment; comment; comment = comment_next )
   {
      comment_next = comment->next;
      UNLINK( comment, ch->pcdata->first_comment, ch->pcdata->last_comment, next, prev );
      free_note( comment );
   }
}

void comment_remove( CHAR_DATA * ch, NOTE_DATA * pnote )
{
   if( !ch )
   {
      bug( "%s: Null ch!", __FUNCTION__ );
      return;
   }

   if( !ch->pcdata->first_comment )
   {
      bug( "%s: Null %s->pcdata->first_comment!", __FUNCTION__, ch->name );
      return;
   }

   if( !pnote )
   {
      bug( "%s: Null pnote, removing comment from %s!", __FUNCTION__, ch->name );
      return;
   }

   UNLINK( pnote, ch->pcdata->first_comment, ch->pcdata->last_comment, next, prev );
   free_note( pnote );

   /*
    * Rewrite entire list.
    * Right, so you mean to tell me this gets called from here, which calls fwrite_char, which calls fwrite_comments...
    * ... Good GODS.. -- Xorith
    */
   save_char_obj( ch );
}

void do_comment( CHAR_DATA * ch, const char *argument )
{
   char arg[MIL];
   NOTE_DATA *pnote;
   CHAR_DATA *victim;
   int vnum;

   if( IS_NPC( ch ) )
   {
      send_to_char( "Mobs can't use the comment command.\r\n", ch );
      return;
   }

   if( !ch->desc )
   {
      bug( "%s", "do_comment: no descriptor" );
      return;
   }

   /*
    * Put in to prevent crashing when someone issues a comment command
    * from within the editor. -Narn 
    */
   if( ch->desc->connected == CON_EDITING )
   {
      send_to_char( "You can't use the comment command from within the editor.\r\n", ch );
      return;
   }

   switch ( ch->substate )
   {
      default:
         break;

      case SUB_WRITING_NOTE:
         if( !ch->pnote )
         {
            bug( "%s", "do_comment: note got lost?" );
            send_to_char( "Your note got lost!\r\n", ch );
            stop_editing( ch );
            return;
         }
         if( ch->dest_buf != ch->pnote )
            bug( "%s", "do_comment: sub_writing_note: ch->dest_buf != ch->pnote" );
         DISPOSE( ch->pnote->text );
         ch->pnote->text = copy_buffer_nohash( ch );
         stop_editing( ch );
         return;
      case SUB_EDIT_ABORT:
         send_to_char( "Aborting note...\r\n", ch );
         ch->substate = SUB_NONE;
         if( ch->pnote )
            free_note( ch->pnote );
         ch->pnote = NULL;
         return;
   }

   set_char_color( AT_NOTE, ch );
   argument = one_argument( argument, arg );
   smash_tilde( argument );

   if( !str_cmp( arg, "list" ) || !str_cmp( arg, "about" ) )
   {
      if( !( victim = get_char_world( ch, argument ) ) )
      {
         send_to_char( "They're not logged on!\r\n", ch );  /* maybe fix this? */
         return;
      }

      if( IS_NPC( victim ) )
      {
         send_to_char( "No comments about mobs\r\n", ch );
         return;
      }

      if( get_trust( victim ) >= get_trust( ch ) )
      {
         send_to_char( "You're not of the right caliber to do this...\r\n", ch );
         return;
      }

      if( !victim->pcdata->first_comment )
      {
         send_to_char( "There are no relevant comments.\r\n", ch );
         return;
      }

      vnum = 0;
      for( pnote = victim->pcdata->first_comment; pnote; pnote = pnote->next )
      {
         vnum++;
         ch_printf( ch, "%2d) %-10s [%s] %s\r\n", vnum, pnote->sender ? pnote->sender : "--Error--",
                    mini_c_time( pnote->date_stamp, -1 ), pnote->subject ? pnote->subject : "--Error--" );
         /*
          * Brittany added date to comment list and whois with above change 
          */
      }
      return;
   }

   if( !str_cmp( arg, "read" ) )
   {
      bool fAll;

      argument = one_argument( argument, arg );
      if( !( victim = get_char_world( ch, arg ) ) )
      {
         send_to_char( "They're not logged on!\r\n", ch );  /* maybe fix this? */
         return;
      }

      if( IS_NPC( victim ) )
      {
         send_to_char( "No comments about mobs\r\n", ch );
         return;
      }

      if( get_trust( victim ) >= get_trust( ch ) )
      {
         send_to_char( "You're not of the right caliber to do this...\r\n", ch );
         return;
      }

      if( !victim->pcdata->first_comment )
      {
         send_to_char( "There are no relevant comments.\r\n", ch );
         return;
      }

      if( !str_cmp( argument, "all" ) )
         fAll = TRUE;
      else if( is_number( argument ) )
         fAll = FALSE;
      else
      {
         send_to_char( "Read which comment?\r\n", ch );
         return;
      }

      vnum = 0;
      for( pnote = victim->pcdata->first_comment; pnote; pnote = pnote->next )
      {
         vnum++;
         if( fAll || vnum == atoi( argument ) )
         {
            note_to_char( ch, pnote, NULL, 0 );
            return;
         }
      }

      send_to_char( "No such comment.\r\n", ch );
      return;
   }

   if( !str_cmp( arg, "write" ) )
   {
      if( !ch->pnote )
         note_attach( ch );
      ch->substate = SUB_WRITING_NOTE;
      ch->dest_buf = ch->pnote;
      if( !ch->pnote->text || ch->pnote->text[0] == '\0' )
         ch->pnote->text = str_dup( "" );
      start_editing( ch, ch->pnote->text );
      return;
   }

   if( !str_cmp( arg, "subject" ) )
   {
      if( !ch->pnote )
         note_attach( ch );
      DISPOSE( ch->pnote->subject );
      ch->pnote->subject = str_dup( argument );
      send_to_char( "Ok.\r\n", ch );
      return;
   }

   if( !str_cmp( arg, "clear" ) )
   {
      if( ch->pnote )
      {
         free_note( ch->pnote );
         send_to_char( "Comment cleared.\r\n", ch );
         return;
      }
      send_to_char( "You arn't working on a comment!\r\n", ch );
      return;
   }

   if( !str_cmp( arg, "show" ) )
   {
      if( !ch->pnote )
      {
         send_to_char( "You have no comment in progress.\r\n", ch );
         return;
      }
      note_to_char( ch, ch->pnote, NULL, 0 );
      return;
   }

   if( !str_cmp( arg, "post" ) )
   {
      if( !ch->pnote )
      {
         send_to_char( "You have no comment in progress.\r\n", ch );
         return;
      }

      argument = one_argument( argument, arg );
      if( !( victim = get_char_world( ch, arg ) ) )
      {
         send_to_char( "They're not logged on!\r\n", ch );  /* maybe fix this? */
         return;
      }

      if( IS_NPC( victim ) )
      {
         send_to_char( "No comments about mobs\r\n", ch );
         return;
      }

      if( get_trust( victim ) > get_trust( ch ) )
      {
         send_to_char( "You failed, and they saw!\r\n", ch );
         ch_printf( victim, "%s has just tried to comment your character!\r\n", ch->name );
         return;
      }

      ch->pnote->date_stamp = current_time;

      pnote = ch->pnote;
      ch->pnote = NULL;

      LINK( pnote, victim->pcdata->first_comment, victim->pcdata->last_comment, next, prev );
      save_char_obj( victim );
      send_to_char( "Comment posted!\r\n", ch );
      return;
   }

   if( !str_cmp( arg, "remove" ) )
   {
      argument = one_argument( argument, arg );
      if( !( victim = get_char_world( ch, arg ) ) )
      {
         send_to_char( "They're not logged on!\r\n", ch );  /* maybe fix this? */
         return;
      }

      if( IS_NPC( victim ) )
      {
         send_to_char( "No comments about mobs\r\n", ch );
         return;
      }

      if( ( get_trust( victim ) >= get_trust( ch ) ) || ( get_trust( ch ) < LEVEL_ETERNAL ) )
      {
         send_to_char( "You're not of the right caliber to do this...\r\n", ch );
         return;
      }

      if( !is_number( argument ) )
      {
         send_to_char( "Comment remove which number?\r\n", ch );
         return;
      }

      vnum = 0;
      for( pnote = victim->pcdata->first_comment; pnote; pnote = pnote->next )
      {
         vnum++;
         if( ( LEVEL_ETERNAL <= get_trust( ch ) ) && ( vnum == atoi( argument ) ) )
         {
            comment_remove( victim, pnote );
            send_to_char( "Comment removed..\r\n", ch );
            return;
         }
      }

      send_to_char( "No such comment.\r\n", ch );
      return;
   }
   send_to_char( "Syntax: comment <argument> <args...>\r\n", ch );
   send_to_char( "  Where argument can equal:\r\n", ch );
   send_to_char( "     write, subject, clear, show\r\n", ch );
   send_to_char( "     list <player>, read <player> <#/all>, post <player>\r\n", ch );
   if( get_trust( ch ) >= LEVEL_ETERNAL )
      send_to_char( "     remove <player> <#>\r\n", ch );
}

void fwrite_comments( CHAR_DATA * ch, FILE * fp )
{
   NOTE_DATA *pnote;

   if( !ch->pcdata->first_comment )
      return;

   for( pnote = ch->pcdata->first_comment; pnote; pnote = pnote->next )
   {
      fprintf( fp, "%s", "#COMMENT2\n" ); /* Set to COMMENT2 as to tell from older comments */
      fwrite_note( pnote, fp );
   }
}

void fread_comment( CHAR_DATA * ch, FILE * fp )
{
   NOTE_DATA *pnote;

   pnote = read_note( fp );
   LINK( pnote, ch->pcdata->first_comment, ch->pcdata->last_comment, next, prev );
}

/* Function kept for backwards compatibility */
void fread_old_comment( CHAR_DATA * ch, FILE * fp )
{
   NOTE_DATA *pnote;

   log_string( "Starting comment conversion..." );
   for( ;; )
   {
      char letter;

      do
      {
         letter = getc( fp );
         if( feof( fp ) )
         {
            fclose( fp );
            fp = NULL;
            return;
         }
      }
      while( isspace( letter ) );
      ungetc( letter, fp );

      CREATE( pnote, NOTE_DATA, 1 );

      if( !str_cmp( fread_word( fp ), "sender" ) )
         pnote->sender = fread_string( fp );

      if( !str_cmp( fread_word( fp ), "date" ) )
         fread_to_eol( fp );

      if( !str_cmp( fread_word( fp ), "to" ) )
         fread_to_eol( fp );

      if( !str_cmp( fread_word( fp ), "subject" ) )
         pnote->subject = fread_string_nohash( fp );

      if( !str_cmp( fread_word( fp ), "text" ) )
         pnote->text = fread_string_nohash( fp );

      if( !pnote->sender )
         pnote->sender = STRALLOC( "None" );
      if( !pnote->subject )
         pnote->subject = str_dup( "Error: Subject not found" );
      if( !pnote->text )
         pnote->text = str_dup( "Error: Comment text not found." );

      pnote->date_stamp = current_time;
      LINK( pnote, ch->pcdata->first_comment, ch->pcdata->last_comment, next, prev );
      return;
   }
}
