/****************************************************************************
 *                   ^     +----- |  / ^     ^ |     | +-\                  *
 *                  / \    |      | /  |\   /| |     | |  \                 *
 *                 /   \   +---   |<   | \ / | |     | |  |                 *
 *                /-----\  |      | \  |  v  | |     | |  /                 *
 *               /       \ |      |  \ |     | +-----+ +-/                  *
 ****************************************************************************
 * AFKMud Copyright 1997-2002 Alsherok. Contributors: Samson, Dwip, Whir,   *
 * Cyberfox, Karangi, Rathian, Cam, Raine, and Tarl.                        *
 *                                                                          *
 * Original SMAUG 1.4a written by Thoric (Derek Snider) with Altrag,        *
 * Blodkai, Haus, Narn, Scryn, Swordbearer, Tricops, Gorog, Rennard,        *
 * Grishnakh, Fireblade, and Nivek.                                         *
 *                                                                          *
 * Original MERC 2.1 code by Hatchet, Furey, and Kahn.                      *
 *                                                                          *
 * Original DikuMUD code by: Hans Staerfeldt, Katja Nyboe, Tom Madsen,      *
 * Michael Seifert, and Sebastian Hammer.                                   *
 ****************************************************************************
 *                          DNS Resolver Module                             *
 ****************************************************************************/

#define DNS_FILE SYSTEM_DIR "dns.dat"

typedef struct dns_data DNS_DATA;

extern DNS_DATA *first_cache;
extern DNS_DATA *last_cache;

struct dns_data
{
   DNS_DATA *next;
   DNS_DATA *prev;
   char *ip;
   char *name;
   time_t time;
};

DECLARE_DO_FUN( do_cache );
void resolve_dns( DESCRIPTOR_DATA * d, long ip );
void process_dns( DESCRIPTOR_DATA * d );
char *in_dns_cache( char *ip );
void load_dns( void );
void check_dns( void );
