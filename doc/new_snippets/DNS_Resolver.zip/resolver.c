/****************************************************************************
 *                   ^     +----- |  / ^     ^ |     | +-\                  *
 *                  / \    |      | /  |\   /| |     | |  \                 *
 *                 /   \   +---   |<   | \ / | |     | |  |                 *
 *                /-----\  |      | \  |  v  | |     | |  /                 *
 *               /       \ |      |  \ |     | +-----+ +-/                  *
 ****************************************************************************
 * AFKMud Copyright 1997-2002 Alsherok. Contributors: Samson, Dwip, Whir,   *
 * Cyberfox, Karangi, Rathian, Cam, Raine, and Tarl.                        *
 *                                                                          *
 * Original SMAUG 1.4a written by Thoric (Derek Snider) with Altrag,        *
 * Blodkai, Haus, Narn, Scryn, Swordbearer, Tricops, Gorog, Rennard,        *
 * Grishnakh, Fireblade, and Nivek.                                         *
 *                                                                          *
 * Original MERC 2.1 code by Hatchet, Furey, and Kahn.                      *
 *                                                                          *
 * Original DikuMUD code by: Hans Staerfeldt, Katja Nyboe, Tom Madsen,      *
 * Michael Seifert, and Sebastian Hammer.                                   *
 ****************************************************************************
 *			 External DNS Resolver Module			                *
 ****************************************************************************/

/***************************************************************************
 *                          SMC version 0.9.7b3                            *
 *          Additions to Rom2.3 (C) 1995, 1996 by Tom Adriaenssen          *
 *                                                                         *
 * Share and enjoy! But please give the original authors some credit.      *
 *                                                                         *
 * Ideas, tips, or comments can be send to:                                *
 *          tadriaen@zorro.ruca.ua.ac.be                                   *
 *          shadow@www.dma.be                                              *
 ***************************************************************************/

/* This had an identd routine as well, but it's been removed since Smaug
 * handles that in another file.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>

char *resolve_address( int address )
{
   static char addr_str[256];
   struct hostent *from;
   int addr;
    
   if( ( from = gethostbyaddr( (char*)&address, sizeof(address), AF_INET ) ) != NULL )
   {
      strcpy( addr_str, 
    	strcmp( from->h_name, "localhost" ) ? from->h_name : "local-host" );
   }
   else
   {
    	addr = ntohl( address );
    	snprintf( addr_str, 256, "%d.%d.%d.%d",
	    ( addr >> 24 ) & 0xFF, ( addr >> 16 ) & 0xFF,
	    ( addr >>  8 ) & 0xFF, ( addr       ) & 0xFF );
   } 
   return addr_str;
}

int main( int argc, char *argv[] )
{
   int ip;
   char *address;
    
   if( argc != 2 )
   {
      printf( "unknown.host\r\n" );
    	exit( 0 );
   }
    
   ip = atoi( argv[1] );
    
   address = resolve_address( ip );
    
   printf( "%s\r\n", address );
   exit( 0 );
}
