Account System README
----------------------------------------------


To install the Account System
----------------------------------------------

1) Drop account.c and account.h into your src folder

2) Apply the account.patch (You may need to handpatch)

3) In the main folder create a folder named "accounts" (without quotes)

4) Inside accounts create folders a-z

IMPORTANT INFORMATION:
----------------------------------------------

1) This system is a work in progress and has not been fully bug tested and may cause crashes and have issues.
   If you find any problems/fixes please email them to novotellus@hotmail.com

2) There are commented out code for works in progress or old code, these are unstable and may cause your MUD to crash if used.

