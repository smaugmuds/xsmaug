/*
 *  Slotlist immortal command
 *  Author: Cronel (cronel_kal@hotmail.com)
 *  of FrozenMUD (empire.digiunix.net 4000)
 *
 *  Permission to use and distribute this code is granted provided
 *  this header is retained and unaltered, and the distribution
 *  package contains all the original files unmodified.
 *  If you modify this code and use/distribute modified versions
 *  you must give credit to the original author(s).
 */

#include <stdio.h>
#include "mud.h"

void do_slotlist( CHAR_DATA *ch, char *argument )
{
	sh_int slot;
	sh_int sn, sn_count, last_slot_found;

	sn_count = top_sn;
	last_slot_found = 0;
	for( slot = 0; sn_count > 0 ; slot++ )
	{
		for( sn = 0 ; sn < top_sn ; sn ++ )
		{
			if( skill_table[sn]->slot == slot )
			{
				if( slot - last_slot_found > 1 )
				{
					set_pager_color( AT_YELLOW, ch );
					if( slot - last_slot_found > 2 )
						pager_printf( ch, "Slot: %-5d - %5d \t   Unused\n\r",
							last_slot_found + 1,
							slot - 1);
					else
						pager_printf( ch, "Slot: %-5d       \t   Unused\n\r",
							slot - 1);
				}
				set_pager_color( AT_BLUE, ch );
				pager_printf( ch, "Slot: %-5d \t (%-7s) %-20.20s ",
					slot,
					skill_tname[skill_table[sn]->type],
					skill_table[sn]->name );

				if( slot == 0 && skill_table[sn]->type == SKILL_SPELL )
				{
					set_pager_color( AT_RED, ch );
					pager_printf( ch, "(WARNING: Spell with slot 0) ");
				}


				if( slot == last_slot_found && slot != 0 )
				{
					set_pager_color( AT_RED, ch );
					pager_printf( ch, "(WARNING: Duplicate slot) ");
				}

				pager_printf( ch, "\n\r" );
				last_slot_found = slot;
				sn_count --;
			}
		}
	}
}
